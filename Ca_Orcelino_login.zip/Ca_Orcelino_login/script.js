let w, n;

document.getElementById("paswrd").innerHTML = w;
document.getElementById("usrnm").innerHTML = n;

//output if the user does not comply
function  rturn(){
    if (w === " "){
     document.getElementById("rtrn").innerHTML = ("Please input a username.");
    }
    else if (n === " "){
     document.getElementById("rtrn").innerHTML = ("Please input a password.");
    }
    else{
     document.getElementById("rtrn").innerHTML = ("Please input a password and a username.");
    }
}